#ifdef SCUBA

#include "config.h"
#include "platform.h"
#include "Audio.h"
#include "RS485Reader.h"

const int saveValues[] = { 127, 127, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

// ----------------------------------------------------------------------------
// Action list
// ----------------------------------------------------------------------------
Action myActionList[NUM_ACTIONS] = {
    Action(KEY_ACTION(KEY_BIT_5),  -1, DIRECT, nullptr, 100, 1, &player1), // [0]  bubble track
    Action(KEY_ACTION(KEY_BIT_8),  -1, DIRECT, nullptr, 100, 2, &player1), // [1]  jaws track
    Action(0,   14, DIRECT),                            // [2]  hoofd        (mux ch 0)
    Action(2,    1, DIRECT),                            // [3]  snorkel      (mux ch 2)
    Action(3,    2, DIRECT),                            // [4]  snorkel      (mux ch 3)
    Action(5,    3, DIRECT),                            // [5]  spuit        (mux ch 5)
    Action(6,    4, DIRECT),                            // [6]  motorkap open valve
    Action(7,    5, DIRECT),                            // [7]  motorkap close valve
    Action(KEY_ACTION(KEY_BIT_1), 10, DIRECT),          // [8]  toeter
    Action(KEY_ACTION(KEY_BIT_3),  7, DIRECT),          // [9]  toeter
    Action(KEY_ACTION(KEY_BIT_HASH), 8, DIRECT),        // [10] bellen
    Action(KEY_ACTION(KEY_BIT_0),  9, DIRECT),          // [11]
    Action(KEY_ACTION(KEY_BIT_STAR), 15, DIRECT),       // [12] rook
};

// ----------------------------------------------------------------------------
// Sequence: jaws animation
// ----------------------------------------------------------------------------
ActionSequence jaws(4, TRIGGER, false);

static void configureSequences() {
    jaws.addEvent(0,      EVENT_START, &myActionList[1]);  // start jaws audio
    jaws.addEvent(17500,  EVENT_START, &myActionList[12]); // smoke ON
    jaws.addEvent(20000,  EVENT_STOP,  &myActionList[12]); // smoke OFF
    jaws.addEvent(20000,  EVENT_START, &myActionList[6]);  // hood OPEN valve ON
    jaws.addEvent(23500,  EVENT_STOP,  &myActionList[6]);  // hood OPEN valve OFF
    jaws.addEvent(23500,  EVENT_START, &myActionList[7]);  // hood CLOSE valve ON
    jaws.addEvent(24900,  EVENT_STOP,  &myActionList[7]);  // hood CLOSE valve OFF
    jaws.addEvent(24900,  EVENT_STOP,  &myActionList[1]);  // stop jaws audio → triggers bg resume
}

// ----------------------------------------------------------------------------
// Platform interface
// ----------------------------------------------------------------------------
void platformSetup() {
    RS485WriteByte(18, 1, 1);   // motor active
    delay(300);
    RS485WriteByte(18, 2, 0);   // motor neutral
    RS485WriteByte(22, 1, 127); // steer neutral
    configureSequences();
}

void platformLoop() {
    jaws.update();
    // processBackground() runs on Core 1 via platformLoopCore1()
}

void platformScreen() {
    if (jaws.isPlaying()) display.print(F("jaws"));
}

void platformOnIdle() {
    RS485WriteByte(18, 2, 0);   // motor neutral
    RS485WriteByte(22, 1, 127); // steer neutral
}


// Core 1: audio init and background track management
void platformSetup1() {
    audioInit();        // SoftwareSerial for DFRobot players — off Core 0
}

void platformLoopCore1() {
    drainAudioQueue();   // execute any play/pause requests from Core 0
    processBackground(); // restart bubble track if needed
}

#endif // SCUBA