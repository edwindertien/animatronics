#ifndef ACTION_H
#define ACTION_H

#include <Arduino.h>
#include "Motor.h"
#include "Audio.h"      // provides DFRobot_DF1201S type + conditional externs

#define DIRECT 0
#define TOGGLE 1
#define TRIGGER 2

// Button encoding:
//   0-15  = mux switch channel (getRemoteSwitch)
//   100+  = keypad bit (KEY_ACTION(KEY_BIT_x) uses getRemoteKey)
#define KEY_ACTION(bit)  (100 + (bit))

class Action {
  private:
    Motor* motor = nullptr;
    int motorvalue = 0;
    int tracknr = 0;
    int track = 0;
#if USE_AUDIO >= 1
    DFRobot_DF1201S* player = nullptr;
#endif
    int button;
    int relaynr;
    int mode;
    int state;
    int previousState;
    void init();

  public:
    Action(int button, int relaynr, int mode);
    Action(int button, int relaynr, int mode, Motor* motor, int motorvalue);
#if USE_AUDIO >= 1
    Action(int button, int relaynr, int mode, Motor* motor, int motorvalue, int track, DFRobot_DF1201S* player);
#endif
    void update();
    void trigger();
    void stop();
    int getState();
};
#endif